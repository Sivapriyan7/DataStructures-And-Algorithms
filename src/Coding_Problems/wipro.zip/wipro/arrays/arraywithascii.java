package wipro.arrays;

public class arraywithascii {
    public static void main(String[] args) {
        int[] asciiValues = {72, 101, 108, 108, 111};

        for (int asciiValue : asciiValues) {
            System.out.print((char) asciiValue + " ");
        }
    }
}

