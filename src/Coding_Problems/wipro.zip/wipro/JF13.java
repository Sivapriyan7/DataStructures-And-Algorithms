package wipro;//  Write a program to receive a number and print the corresponding month name.

// Example1)

// C:\>java Sample 12

// O/P Expected : December

// Example2)

// C:\>java Sample 

// O/P Expected : Please enter the month in numbers

// Example3)

// C:\>java Sample 15

// O/P Expected : Invalid month

import java.util.*;

public class JF13
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int month=sc.nextInt();

        switch month;
        {
            case 1:
            {
                System.out.println("Jan");
                break;
            }
            case 2:
            {
                System.out.println("Feb");
                break;
            }
            case 3:
            {
                System.out.println("Mar");
                break;
            }
            case 4:
            {
                System.out.println("Apr");
                break;
            }
            case 5:
            {
                System.out.println("May");
                break;
            }
            case 6:
            {
                System.out.println("jun");
                break;
            }
            case 7:
            {
                System.out.println("jul");
                break;
            }
            case 8:
            {
                System.out.println("Aug");
                break;
            }
            case 9:
            {
                System.out.println("Sep");
                break;
            }
            case 10:
            {
                System.out.println("Oct");
                break;
            }
            case 11:
            {
                System.out.println("Now");
                break;
            }
            case 12:
            {
                System.out.println("Des");
                break;
            }
            default:
            {
                System.out.println("Invalid Month");
                break;
            }
        }
    }
}