package wipro.FlowcontrolStatements;

public class evenbetweenranges {
    public static void main(String[] args) {
        System.out.println("Even numbers between 23 and 57:");
        for (int i = 24; i <= 56; i += 2) {
            System.out.println(i);
        }
    }
}


