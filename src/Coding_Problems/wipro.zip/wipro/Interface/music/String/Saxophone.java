package wipro.Interface.music.String;


public class Saxophone implements Playable {
    @Override
    public void play() {
        System.out.println("Playing the Saxophone.");
    }
}
