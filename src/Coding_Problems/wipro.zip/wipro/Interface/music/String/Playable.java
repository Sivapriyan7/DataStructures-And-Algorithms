package wipro.Interface.music.String;

public interface Playable {
    void play();
}
