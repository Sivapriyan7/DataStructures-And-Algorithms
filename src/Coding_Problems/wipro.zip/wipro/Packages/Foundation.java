package wipro.Packages;

public class Foundation {
    private int var1;          // private variable
    int var2;                 // default (package-private) variable
    protected int var3;       // protected variable
    public int var4;          // public variable
}
