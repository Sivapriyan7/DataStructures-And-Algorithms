package wipro.ExceptionHandling;

public class outofRangeException extends Exception {
    public outofRangeException(String message) {
        super(message);
    }
}

