package wipro.ExceptionHandling;

public class NegativevalueException extends Exception {
    public NegativevalueException(String message) {
        super(message);
    }
}

